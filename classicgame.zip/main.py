import tkinter as tk
import subprocess


def run_python_file(file_path):
    subprocess.Popen(["python", file_path])


def button1_clicked():
    run_python_file("subclasses/snake.py")


def button2_clicked():
    run_python_file("subclasses/flappybird.py")


def button3_clicked():
    run_python_file("subclasses/tictactoe.py")

root = tk.Tk()
root.title("سید متین پرهیزکار")
root.geometry("500x400")
label = tk.Label(root, text="کاری از سید متین پرهیزکار")
label.pack(pady=10)
label = tk.Label(root, text="کلاس 8/3 مدرسه حسن برزگر")
label.pack(pady=10)
button1 = tk.Button(root, width=20, height=5,
                    text="مار بازی", command=button1_clicked)

button1.pack()

button2 = tk.Button(root, width=20, height=5,
                    text="هواپیما", command=button2_clicked)
button2.pack()

button3 = tk.Button(root, width=20, height=5,
                    text="دایره و ضربدر", command=button3_clicked)
button3.pack()
root.mainloop()
