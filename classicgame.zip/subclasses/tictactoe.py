import tkinter as tk
from tkinter import messagebox
import random

class TicTacToeMenu:
    def __init__(self, master):
        self.master = master
        self.master.title("ضربدر و دایره")
        self.create_widgets()

    def create_widgets(self):
        self.difficulty_label = tk.Label(self.master, text="انتخاب درجه سختی:", font=("Helvetica", 14))
        self.difficulty_label.pack(pady=10)

        self.difficulty_var = tk.StringVar()
        self.difficulty_var.set("easy")

        easy_button = tk.Radiobutton(self.master, text="آسان", font=("Helvetica", 12),
                                     variable=self.difficulty_var, value="easy")
        easy_button.pack()

        medium_button = tk.Radiobutton(self.master, text="متوسط", font=("Helvetica", 12),
                                       variable=self.difficulty_var, value="medium")
        medium_button.pack()

        hard_button = tk.Radiobutton(self.master, text="سخت", font=("Helvetica", 12),
                                     variable=self.difficulty_var, value="hard")
        hard_button.pack()

        start_button = tk.Button(self.master, text="شروع بازی", font=("Helvetica", 14),
                                  command=self.start_game)
        start_button.pack(pady=10)

    def start_game(self):
        self.master.destroy()
        root = tk.Tk()
        game = TicTacToeGUI(root, mode="ai", difficulty=self.difficulty_var.get())
        root.mainloop()

class TicTacToeGUI:
    def __init__(self, master, mode, difficulty):
        self.master = master
        self.mode = mode
        self.difficulty = difficulty
        self.master.title("Tic Tac Toe")
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.current_player = "X"
        self.create_widgets()

    def create_widgets(self):
        self.buttons = [[None for _ in range(3)] for _ in range(3)]
        for i in range(3):
            for j in range(3):
                self.buttons[i][j] = tk.Button(self.master, text=" ", font=("Helvetica", 20), width=6, height=3,
                                               command=lambda row=i, col=j: self.on_click(row, col))
                self.buttons[i][j].grid(row=i, column=j)
        self.status_label = tk.Label(self.master, text="X نوبت", font=("Helvetica", 14))
        self.status_label.grid(row=3, columnspan=3)

    def on_click(self, row, col):
        if self.board[row][col] == " ":
            self.board[row][col] = self.current_player
            self.buttons[row][col].config(text=self.current_player)
            if self.check_winner(self.current_player):
                self.end_game(f"{self.current_player} برد!")
            elif all(self.board[i][j] != " " for i in range(3) for j in range(3)):
                self.end_game("بازی مساوی شد!")
            else:
                self.current_player = "O" if self.current_player == "X" else "X"
                self.status_label.config(text=f"Player {self.current_player}'s turn")
                if self.mode == "ai" and self.current_player == "O":
                    self.ai_move()

    def ai_move(self):
        if self.difficulty == "easy":
            self.ai_move_easy()
        elif self.difficulty == "medium":
            self.ai_move_medium()
        elif self.difficulty == "hard":
            self.ai_move_hard()

    def ai_move_easy(self):
        empty_cells = [(i, j) for i in range(3) for j in range(3) if self.board[i][j] == " "]
        row, col = random.choice(empty_cells)
        self.on_click(row, col)

    def ai_move_medium(self):
        # Implement a simple greedy algorithm
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == " ":
                    self.on_click(i, j)
                    return

    def ai_move_hard(self):
        # Implement Minimax algorithm
        best_score = float("-inf")
        best_move = None
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == " ":
                    self.board[i][j] = "O"
                    score = self.minimax(self.board, 0, False)
                    self.board[i][j] = " "
                    if score > best_score:
                        best_score = score
                        best_move = (i, j)
        row, col = best_move
        self.on_click(row, col)

    def minimax(self, board, depth, is_maximizing):
        if self.check_winner("O"):
            return 1
        elif self.check_winner("X"):
            return -1
        elif all(board[i][j] != " " for i in range(3) for j in range(3)):
            return 0

        if is_maximizing:
            best_score = float("-inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == " ":
                        board[i][j] = "O"
                        score = self.minimax(board, depth + 1, False)
                        board[i][j] = " "
                        best_score = max(score, best_score)
            return best_score
        else:
            best_score = float("inf")
            for i in range(3):
                for j in range(3):
                    if board[i][j] == " ":
                        board[i][j] = "X"
                        score = self.minimax(board, depth + 1, True)
                        board[i][j] = " "
                        best_score = min(score, best_score)
            return best_score

    def check_winner(self, player):
        for row in self.board:
            if all(cell == player for cell in row):
                return True
        for col in range(3):
            if all(self.board[row][col] == player for row in range(3)):
                return True
        if all(self.board[i][i] == player for i in range(3)) or all(self.board[i][2 - i] == player for i in range(3)):
            return True
        return False

    def end_game(self, message):
        messagebox.showinfo("Game Over", message)
        self.reset_board()

    def reset_board(self):
        self.board = [[" " for _ in range(3)] for _ in range(3)]
        self.current_player = "X"
        for i in range(3):
            for j in range(3):
                self.buttons[i][j].config(text=" ")
        self.status_label.config(text="Player X's turn")

def main():
    root = tk.Tk()
    menu = TicTacToeMenu(root)
    root.mainloop()

if __name__ == "__main__":
    main()
